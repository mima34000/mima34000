
function isPrimitive(val) {
  return ["number", "boolean", "string", "undefined"].includes(typeof val);
}

function isObject(val) {
  return typeof val === "object";
}


Object.prototype.equals = function (otherObj) {
  const thisKeys = Object.keys(this);
  const otherKeys = Object.keys(otherObj);
  if (thisKeys.length !== otherKeys.length) {
    return false;
  }
  for (let key of thisKeys) {
    const thisVal = this[key];
    const otherVal = otherObj[key];
    if (typeof thisVal !== "object") {
      if (thisVal !== otherVal) {
        return false;
      }
    } else {
      if (!thisVal.equals(otherVal)) {
        return false;
      }
    }
  }
  return true;
};

Array.prototype.contains = function (value) {
  if (isObject(value) && value.length === undefined) {
    for (let i = 0; i < this.length; i++) {
      if (value.equals(this[i])) {
      
        return true;
      }
    }
  }
  if (isPrimitive(value)) {
    return this.includes(value); 
  }
  return false;
};

const rows = 10;
const cols = 10;
const nrOfShips = 1;

const player1 = {
  mark: 1,
  boms: [],
  hits: [],
  ships: [],
};

const player2 = {
  mark: 2,
  boms: [],
  hits: [],
  ships: [],
};

let players = { current: player1, enemy: player2 };

function isValidCoord(coord) {
  {
  return (
    isObject(coord) &&
    typeof coord.row === "number" &&
    typeof coord.col === "number" &&
    coord.row >= 0 &&
    coord.row < rows &&
    coord.col >= 0 &&
    coord.col < cols
  );
}
}

function isValidShip(ship) {
  if (ship.length < 2 || ship.length > 5) return false;
  for (let i = 0; i < ship.length; i++) {
    if (!isValidCoord(ship[i])) return false;
  }
  const isHorizontal = ship.every((coord) => coord.row === ship[0].row);
  const isVertical = ship.every((coord) => coord.col === ship[0].col);

  if (!isHorizontal && !isVertical) return false;

  for (let i = 1; i < ship.length; i++) {
    if (isHorizontal && ship[i].col !== ship[i - 1].col + 1) return false;
    if (isVertical && ship[i].row !== ship[i - 1].row + 1) return false;
  }

  return true;
}
function promtUserForShipCoords(mark, nr) {
  const input = prompt(`Player ${mark}, Ship ${nr}:`);
  const array = input.split(" "); 
  const ship = [];
  
  for (let text of array) {
    const [y, x] = text.split(","); 
    ship.push({ row: parseInt(y), col: parseInt(x) }); 
  }
  if (isValidShip(ship)) {
    return ship;
  } else {
    console.error(`  * Ships must be straigh lines
    * Each coordinate of ship must be inside board
    * Each ship must be larger than 2 coordinates
    * Each ship must not be longer than 5 coordinates`);
    return promtUserForShipCoords(mark, nr); 
  }
}

function displayMarkersOnGrid(markers) {
  let textBoard = "_____________________\n";
  for (let row = 0; row < rows; row++) {
    textBoard += "|";
    for (let col = 0; col < cols; col++) {
      let cell = null;
      
      markers.forEach(function (marker) {
        if (marker.row === row && marker.col === col) {
          cell = marker.mark;
        }
      });
      
      if (cell !== null) {
        textBoard += `${cell}|`;
      } else {
        textBoard += `_|`;
      }
    }
    textBoard += "\n"; 
  }
  console.log(textBoard); 
}

function drawEmptyBoard() {
  displayMarkersOnGrid([]);
}
function initializeShips(player) {
  console.log(`Choose your ${nrOfShips} ships!`);
  drawEmptyBoard();
  player.ships = []; 
  for (let i = 0; i < nrOfShips; i++) {
   
    const newShip = promtUserForShipCoords(player.mark, i + 1);
    console.clear();
    player.ships = [...newShip, ...player.ships]; 
    const markedShips = player.ships.map((coord) => ({
      ...coord,
      mark: player.mark,
    }));
    displayMarkersOnGrid(markedShips); 
  }
  const ok = confirm("Press Ok if you are happy with your ships.");
  if (ok) {
    console.clear();
  } else {
    initializeShips(player);
  }
}

function markCoord(coord, mark){
  return { ...coord, mark };
}

function hasLost(player){
 
  return player.ships.every((shipCoord) =>
    player.hits.some((hitCoord) => hitCoord.row === shipCoord.row && hitCoord.col === shipCoord.col)
  );
}
function registerHitOrBom(guess, player) {
  const isHit = player.ships.some(
    (shipCoord) => shipCoord.row === guess.row && shipCoord.col === guess.col
  );

  if (isHit) {
    player.hits.push(guess);
  } else {
    player.boms.push(guess);
  }
}


function switchPlayers(players) {
  return {
    current: players.enemy,
    enemy: players.current,
  };
}


function displayGameOver(winner, loser) {
  console.log(`Player ${winner.mark} won over player ${loser.mark}!`);
}

function promptPlayerForGuess(player) {
  const input = prompt(`Player ${player.mark}, Choose your target:`);
  const [y, x] = input.split(","); 
  const guess = { row: parseInt(y), col: parseInt(x) }; 
  if (!isValidCoord(guess)) {
    console.error(
      `You must provide coordinates (0-${rows},0-${cols}) for a strike between at (row, col)`
    );
    guess = promptPlayerForGuess(player); 
  }
  return guess;
}

function displayHitsAndBoms(player) {
  console.clear();
  const markedHits = player.hits.map((coord) => ({
    ...coord,
    mark: player.mark,
  }));
  const markedBoms = player.boms.map((coord) => ({
    ...coord,
    mark: "X",
  }));
  displayMarkersOnGrid([...markedHits, ...markedBoms]);
}
function gameLoop() {
  const maxIterations = rows * cols;
  for (let i = 0; i < maxIterations; i++) {
    let guess = promptPlayerForGuess(players.current); 
    registerHitOrBom(guess, players.enemy); 
    displayHitsAndBoms(players.enemy);
    if (hasLost(players.enemy)) {
      displayGameOver(players.current, players.enemy);
      break;
    }
    players = switchPlayers(players); 
  }
}

///////////////////// game start //////////////////////////

function runGame() {
  initializeShips(player1);
  initializeShips(player2);
  gameLoop();
}

runGame();

